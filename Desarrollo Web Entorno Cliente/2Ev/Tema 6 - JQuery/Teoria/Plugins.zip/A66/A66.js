$(document).ready(function () {
$(".page-header").funText(33, 'rainbow');
$("a").funText(11,'candy');
})